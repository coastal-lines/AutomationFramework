﻿using AutomationProjectQA;
using NUnit.Framework;
using OpenQA.Selenium;

namespace TestsProject
{
    public class BaseTestsClass
    {
        private IWebDriver driver;

        public IWebDriver GetDriver()
        {
            if (driver == null)
            {
                InitDriver();
            }

            return driver;
        }

        public void InitDriver()
        {
            driver = BaseFrameworkClass.CreateDriver();
        }

        [TearDown]
        public void CleanDriver()
        {
            if (driver != null)
            {
                driver.Close();
                driver.Dispose();
            }
        }
    }
}