﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;

namespace AutomationProjectQA.Wrapers
{
    public class Element
    {
        private IWebDriver driver;
        private IWebElement element;

        public Element(By by)
        {
            driver = BaseFrameworkClass.GetDriver();
            element = driver.FindElement(by);
        }
    }
}
